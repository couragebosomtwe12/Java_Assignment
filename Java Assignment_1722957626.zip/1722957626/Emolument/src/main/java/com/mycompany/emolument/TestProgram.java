/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.emolument;

/**
 *
 * @author coura
 */
import java.util.Scanner;

public class TestProgram {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Accept input from the user
        System.out.print("Enter Basic Salary: ");
        double basicSalary = scanner.nextDouble();
        System.out.print("Enter Tax Relief: ");
        double taxRelief = scanner.nextDouble();

        // Create MyEmolument object
        MyEmolument staffSalary = new MyEmolument(basicSalary, taxRelief);

        // Display the results
        System.out.println("Basic Salary: " + staffSalary.getBasicsalary());
        System.out.println("Tax Relief: " + staffSalary.getTaxRelief());
        System.out.println("SSNIT Contribution: " + staffSalary.SSNIT());
        System.out.println("Taxable Income: " + staffSalary.taxableIncome());
        System.out.println("Income Tax: " + staffSalary.incomeTax());
        System.out.println("Total Deduction: " + staffSalary.totalDeduction());
        System.out.println("Net Salary: " + staffSalary.netSalary());

        scanner.close();
    }
}
