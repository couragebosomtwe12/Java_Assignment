/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.emolument;

/**
 *
 * @author coura
 */
class Emolument {
    private double basic_salary;
    private double tax_relief;
    // Constructor to create emolument with specified Basic Salary and Tax Relief
    public Emolument(double basic_salary, double tax_relief) {
        this.basic_salary = basic_salary;
        this.tax_relief = tax_relief;
    }
    // Method to get the basic salary
    public double getBasicsalary() {
        return basic_salary;
    }

    // Method to get the tax relief
    public double getTaxRelief() {
        return tax_relief;
    }
    // Method to calculate SSNIT contribution (3.5% of Basic Salary)
    public double SSNIT() {
        return basic_salary * 0.035;
    }

    // Method to calculate Taxable Income (Basic salary - (Tax relief + SSNIT contribution))
    public double taxableIncome() {
        return basic_salary - (tax_relief + SSNIT());
    }


}
