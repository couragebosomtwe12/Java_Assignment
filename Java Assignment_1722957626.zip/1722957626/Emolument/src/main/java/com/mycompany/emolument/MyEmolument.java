/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.emolument;

/**
 *
 * @author coura
 */
class MyEmolument extends Emolument {
    // Non-arg constructor that creates a default emolument (0 for basic salary and tax relief)
    public MyEmolument() {
        super(0, 0);
    }
    
     // Constructor that creates MyEmolument with specified basic salary and tax relief
    public MyEmolument(double basic_salary, double tax_relief) {
        super(basic_salary, tax_relief);
    }
     // Method to compute Income Tax
    public double incomeTax() {
        double taxableIncome = taxableIncome();
        double incomeTax = 0;

        if (taxableIncome <= 500) {
            incomeTax = taxableIncome * 0.05;
        } else if (taxableIncome <= 1000) {
            incomeTax = 500 * 0.05 + (taxableIncome - 500) * 0.125;
        } else {
            incomeTax = 500 * 0.05 + 500 * 0.125 + (taxableIncome - 1000) * 0.175;
        }
        return incomeTax;
    }

    // Method to compute Total Deduction (SSNIT Contribution + Income Tax)
    public double totalDeduction() {
        return SSNIT() + incomeTax();
    }
  // Method to compute Net Salary (Basic salary - Total Deduction)
    public double netSalary() {
        return getBasicsalary() - totalDeduction();
    }

    String getBasicSalary() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String gettaxrelief() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}


