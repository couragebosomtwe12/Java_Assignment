/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.statisticscalculator;

/**
 *
 * @author coura
 */
import java.util.Arrays;
import java.util.Scanner;

public class StatisticsCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user to enter the number of elements in the array
        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();

        // Accept the user's input for each element of the array
        double[] numbers = new double[n];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            numbers[i] = scanner.nextDouble();
        }

        // Assign the functions used to calculate mean, median and standard deviation to variables
        double mean = calculateMean(numbers);
        double median = calculateMedian(numbers);
        double standardDeviation = calculateStandardDeviation(numbers);

        // Display the mean, median and standard deviation
        System.out.printf("Mean: %.2f\n", mean);
        System.out.printf("Median: %.2f\n", median);
        System.out.printf("Standard Deviation: %.2f\n", standardDeviation);
    }

    // Function to calculate the mean (average) of the entered numbers
    public static double calculateMean(double[] numbers) {
        double sum = 0;
        for (double number : numbers) {
            sum += number;
        }
        return sum / numbers.length;
    }

    // Function to calculate the median (middle value) of the entered numbers
    public static double calculateMedian(double[] numbers) {
        Arrays.sort(numbers);
        int n = numbers.length;
        if (n % 2 == 0) {
            return (numbers[n / 2 - 1] + numbers[n / 2]) / 2;
        } else {
            return numbers[n / 2];
        }
    }

    // Function to calculate the standard deviation of the entered numbers
    public static double calculateStandardDeviation(double[] numbers) {
        double mean = calculateMean(numbers);
        double sum = 0;
        for (double number : numbers) {
            sum += Math.pow(number - mean, 2);
        }
        return Math.sqrt(sum / numbers.length);
    }
  
}
